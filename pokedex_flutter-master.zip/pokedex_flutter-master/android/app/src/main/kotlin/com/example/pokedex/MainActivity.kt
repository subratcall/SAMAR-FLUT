package com.example.pokedex

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
