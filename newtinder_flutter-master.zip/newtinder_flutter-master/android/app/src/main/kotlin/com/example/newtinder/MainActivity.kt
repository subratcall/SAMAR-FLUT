package com.example.newtinder

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
