import 'package:flutter/material.dart';
import 'package:logging_app/screen/authenticate/Authenticate.dart';

class Wrapper extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Authenticate();
  }
}
