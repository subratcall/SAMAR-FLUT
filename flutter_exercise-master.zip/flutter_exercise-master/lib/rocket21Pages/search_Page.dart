import 'package:flutter/material.dart';

class search_Page extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.deepOrange[300],
    );
  }
}