import 'package:flutter/material.dart';

class addBox_Page extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.purpleAccent[100],
    );
  }
}