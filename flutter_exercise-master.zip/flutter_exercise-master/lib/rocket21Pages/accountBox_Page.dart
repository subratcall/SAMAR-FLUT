import 'package:flutter/material.dart';

class accountBox_Page extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.red,
    );
  }
}
