import 'package:flutter/material.dart';

class favorite_Page extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.pinkAccent[100],
    );
  }
}