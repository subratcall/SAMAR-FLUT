package com.example.flutter_exercise

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
