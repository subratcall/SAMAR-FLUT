package com.example.agri_shopping

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
