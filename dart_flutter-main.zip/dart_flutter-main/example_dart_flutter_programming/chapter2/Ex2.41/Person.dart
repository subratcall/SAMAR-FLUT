class Person {
  String name;
  int _age;

  eat() {
    print('eat');
  }

  _sleep() {
    print('sleep');
  }
}
