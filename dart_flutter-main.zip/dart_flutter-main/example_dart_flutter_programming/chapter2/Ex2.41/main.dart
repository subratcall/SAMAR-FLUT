import 'package:dartEx01/src/Person.dart';

main() {
  Person p = Person();
  p.eat();
//  p._sleep(); error
}
