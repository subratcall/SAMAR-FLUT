main() {
  var number;
  print('The number is $number.');

  number = 10;
  print('The number is $number.');
}
