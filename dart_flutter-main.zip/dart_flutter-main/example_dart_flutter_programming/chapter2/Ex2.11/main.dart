main() {
  final int NUMBER = 1;
  const int PRICE = 1000;

  final NAME = 'Kim';
  const COLOR = 'Red';

  print('The NUMBER is $NUMBER.');
  print('The PRICE is $PRICE.');

  print('The NAME is $NAME.');
  print('The COLOR is $COLOR.');
}
