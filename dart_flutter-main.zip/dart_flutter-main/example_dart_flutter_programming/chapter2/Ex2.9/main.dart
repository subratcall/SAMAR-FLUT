main() {
  var number = 10;
  Object balanceA = 1000;
  dynamic balanceB = 2000;
  print('The number is $number.');
  print('The balanceA is $balanceA.');
  print('The balanceB is $balanceB.');

  balanceA = '천';
  balanceB = false;
  print('The balanceA is $balanceA.');
  print('The balanceB is $balanceB.');
}
