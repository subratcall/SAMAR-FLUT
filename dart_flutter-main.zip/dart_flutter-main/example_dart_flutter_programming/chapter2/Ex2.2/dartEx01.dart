printResult(int number) {
  print('The number is $number.');
}
