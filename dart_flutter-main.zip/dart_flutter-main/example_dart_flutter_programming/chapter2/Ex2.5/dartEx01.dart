printResult(int number) {
  print('The number is $number.');
}

class TestA {
  show() {
    print('TestA');
  }
}

class TestB {
  show() {
    print('TestB');
  }
}
