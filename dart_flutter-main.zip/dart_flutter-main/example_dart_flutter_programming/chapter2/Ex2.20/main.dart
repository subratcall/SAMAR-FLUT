main() {
  int a = 10;
  int b = 20;

  if (a == b) {
    print('a == b');
  } else {
    print('a != b');
  }
}
