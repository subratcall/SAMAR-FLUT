main() {
  int a = 10;
  int b = 10;
  a = a + 5;
  b += 5;

  print('a = $a');
  print('b = $b');
}
