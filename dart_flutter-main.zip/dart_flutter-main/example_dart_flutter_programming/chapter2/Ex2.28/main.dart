main() {
  var student = Student();
}

class Person {
  Person() {
    print('This is Person constructor!');
  }
}

class Student extends Person {}
