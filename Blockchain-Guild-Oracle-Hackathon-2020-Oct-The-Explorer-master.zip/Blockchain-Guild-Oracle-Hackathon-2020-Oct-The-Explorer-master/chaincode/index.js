'use strict';

const smartcontract = require('./smartcontract.js');
module.exports.contracts = [smartcontract];
