## NewTinder

### A simple Tinder-Clone with functions:
- sign-up/sign-in
- swipe cards
- chat

### Especially for mobile devices designed

#### Live preview:
> https://newtinder.vercel.app/
