// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'app.dart';

// **************************************************************************
// FunctionalWidgetGenerator
// **************************************************************************

class App extends HookWidget {
  const App({Key key}) : super(key: key);

  @override
  Widget build(BuildContext _context) => app();
}
