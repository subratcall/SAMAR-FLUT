// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'target_box.dart';

// **************************************************************************
// FunctionalWidgetGenerator
// **************************************************************************

class TargetBox extends HookWidget {
  const TargetBox({Key key}) : super(key: key);

  @override
  Widget build(BuildContext _context) => targetBox();
}
