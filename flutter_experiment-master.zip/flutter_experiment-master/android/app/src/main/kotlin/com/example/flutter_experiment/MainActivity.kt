package com.example.flutter_experiment

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
